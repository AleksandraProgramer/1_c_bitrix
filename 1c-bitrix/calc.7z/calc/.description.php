<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

/*
 * файл описания компонента
 * отображение компонента
*/

$arComponentDescription = array(
	"NAME" => "Задание работодателя",
	"DESCRIPTION" => "Расчетный раздел",
	"ICON" => "/images/calc.gif",
	"COMPLEX" => "Y",
	"PATH" => array(
		"ID" => "Компонент калькулятор",
		"SORT" => 2000,
		"NAME" => "Мои компоненты",
		"CHILD" => array(
			"ID" => "Мой калькулятор",
			"NAME" => "Калькулятор",
			"SORT" => 10,
		),
	),
);

?>