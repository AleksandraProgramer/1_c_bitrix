<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

/*
	Настройки компонента
*/

$arComponentParameters = array(
    "PARAMETERS" => array(
	
		// весовые пороги товара
        "DOSTAVKA" => array(
            "PARENT" => "BASE",
            "NAME" => "Доставка по г.Минск (стоимость)",
            "TYPE" => "STRING",
            "DEFAULT" => "1",
			"REFRESH" => "Y",
            "COLS" => 25
        ),
		
		// весовые пороги товара
		"DOSTAVKA1" => array(
            "PARENT" => "BASE",
            "NAME" => "Доставка по Минскому району (стоимость)",
            "TYPE" => "STRING",
            "DEFAULT" => "5",
			"REFRESH" => "Y",
            "COLS" => 25
        ),
		
		// весовые пороги товара
		"DOSTAVKA2" => array(
            "PARENT" => "BASE",
			"NAME" => "Доставка по Минской области (стоимость)",
            "TYPE" => "STRING",
            "DEFAULT" => "15",
			"REFRESH" => "Y",
            "COLS" => 25
        ),
		
		// весовые пороги товара
        "DOSTAVKA3" => array(
            "PARENT" => "BASE",
            "NAME" => "Доставка по всей Белоруси (стоимость)",
            "TYPE" => "STRING",
            "DEFAULT" => "20",
			"REFRESH" => "Y",
            "COLS" => 25
        ),

    ),
);

?>