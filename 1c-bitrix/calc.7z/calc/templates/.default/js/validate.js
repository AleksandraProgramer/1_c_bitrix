
// валидация данных (функции)
function myvalid(myUrl, id) {
	
	// Объявляем переменные
	var getelement;
	var status = false;
	var mydata = [];
	
	// получаем id элемента
    var i1 = document.getElementById(id);
	
	// получаем наследование по тэгу элемента
	var mySelect = i1.getElementsByTagName('select');
	
	// получаем список элементов
	for(i = 0; i < mySelect.length; i++)
	{
		// получаем индефикатор элементов
		getelement = document.getElementById(mySelect[i].id);
		
		// если поле пустое то подсвечиваем его
		if(getelement.value === '') {
			getelement.classList.add("red_error");
			getelement.options[0].text = "Ты не выбрал(а) !";
			status = false;
		}else{
			getelement.classList.remove("red_error");
			getelement.classList.add("red_access");
			mydata[i] = getelement.value;
			status = true;				
		}		
	}
	
		// если ошибок нет, то отправляем POST	
		if(status == true){	
			$.ajax({
				type: "POST",
				url: myUrl,
				data: { mydata },
			  success: function(data) {
				  
				// прячем форму и выводим список
				document.getElementById("on").style.display = "none";
				document.getElementById("off").style.display = "grid";
				
				// парсим json данные
				var exdata = JSON.parse(data);
				var mysplit = exdata[1].split(':');
				
				// выводим их в список
				document.getElementById("typez").innerHTML = exdata[0];
				document.getElementById("reg").innerHTML = mysplit[1];
				document.getElementById("vid").innerHTML = exdata[2] + " кг.";
				document.getElementById("price").innerHTML = exdata[3] + " BYN";				
			
			  },
			  error: function() {
				alert('Ошибочка вышла!');
			  }		   
			});	
			
		}
    return status;
}