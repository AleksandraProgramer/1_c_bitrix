<?php
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

/*
	Вывод данных компонента
*/

// опции проверки
// \Bitrix\Main\Diag\Debug::dump($arParams);
// \Bitrix\Main\Diag\Debug::dump($arResult);
?>

<link href="<?php echo $this->GetFolder(); ?>/css/style.css" type="text/css"  rel="stylesheet" />
<script type="text/javascript" language="javascript" src="<?php echo $this->GetFolder(); ?>/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo $this->GetFolder(); ?>/js/validate.js"></script>

<!-- Интерфейс -->
<div class="mydiv" id="on">
<div class="myform" id="validselect"> 
<h1>Тестовое задание</h1>
	<label class="myfont">Выбор доставки</label>
	<select id="sposob_dostavki" class="myselect">
	    <option value="">Выберите тип доставки</option>
		<?php for($i = 0; $i < count($arResult['dostavka']); $i++){ ?>
			<option value="<?php echo $arResult['dostavka'][$i]; ?>"><?php echo $arResult['dostavka'][$i]; ?></option>
		<?php } ?>
	</select>

	<label class="myfont">География доставки</label>
	<select id="geografia_dostavki" class="myselect">
	    <option value="">Выберите регион доставки</option>
	   <?php for($j = 0; $j < count($arResult['geo']); $j++){
		   $explodes = explode(":", $arResult['geo'][$j]); ?>
			<option value="<?php echo $arResult['geo'][$j]; ?>"><?php echo $explodes[1]; ?></option>
	   <?php } ?>
	</select>

	<label class="myfont">Весовые пороги товара (кг)</label>
	<select id="vesovie_porogi" class="myselect">
	    <option value="">Выберите тип веса</option>
	   <?php for($k = 0; $k < count($arResult['ves']); $k++){?>
			<option value="<?php echo $arResult['ves'][$k]; ?>"><?php echo $arResult['ves'][$k]; ?></option>
	   <?php } ?>
	</select>
	<div class="mybutton">
	    <button class="mysend" onclick="return myvalid('<?php echo $this->GetFolder(); ?>/details.php', 'validselect');">Заказать</button>
	</div>
</div>
</div>


<div class="mydiv" id="off" style="display: none;">
<div class="myform" id="validselect"> 
<h1>Тестовое задание</h1>
	<label class="myfont">Посылка будет доставлена: </label>
	<div id="typez">&nbsp;</div> 

	<label class="myfont">в регион: </label>
	<div id="reg">&nbsp;</div>

	<label class="myfont">Вес посылки:</label>
	<div id="vid">&nbsp;</div>
	
	<label class="myfont">Стоимость доставки:</label>
	<div id="price">&nbsp;</div>	
	
	<div id="">&nbsp;</div>
	<div id="">Благодарим за заказ! Ожидайте.</div>
</div>
</div>

</body>
</html>