<?php 
//var_dump($_POST["mydata"]);

// присваеваем переменным данные
$sposob = $_POST["mydata"][0];
$geografia = $_POST["mydata"][1];
$ves = $_POST["mydata"][2];
$price = explode(":", $geografia);

// считаем стоимость
$price = $price[0] * $ves;

// хранение данных
$arr_bd = array($sposob, $geografia, $ves, $price);

// выводим отладку данных
//var_dump($arr_bd);

// кодируем в json формат
$json = json_encode($arr_bd, true);
echo $json;

?>